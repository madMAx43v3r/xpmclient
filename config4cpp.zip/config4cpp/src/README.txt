This directory contains all the ".cpp" files of Config4Cpp, plus the
".h" files that are NOT part of the public API.
